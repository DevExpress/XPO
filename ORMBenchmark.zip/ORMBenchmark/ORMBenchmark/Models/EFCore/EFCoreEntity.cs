﻿using System;
using System.Collections.Generic;

namespace ORMBenchmark.Models.EFCore {
    public partial class EFCoreEntity {
        public long Id { get; set; }
        public long Value { get; set; }
    }
}
